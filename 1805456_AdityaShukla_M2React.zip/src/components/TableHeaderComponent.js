import React, { useState, useEffect } from 'react';
import theme, { pxToVh } from '../utils/theme';
import { InputLabel, makeStyles, Paper } from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import Footer from '../components/Footer';
import { Typography } from '@material-ui/core';
import { InputBase, TextField, OutlinedInput, Button } from '@material-ui/core';
import { FunctionsOutlined } from '@material-ui/icons';
import Header from '../components/Header';
import TableComponent from '../components/TableComponent';
import InfiniteScrollComponents from '../components/InfiniteScrollComponents';
import Example from '../components/Example';
// import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import AddInvoiceComponent from '../components/AddInvoiceComponent';



export default function TableHeaderComponent(props) {
    const classes = useStyles();
    const [open, setOpen] = useState(false);

    const handleDeleteClick = () => {

    }
    const handleClose = () => {
        setOpen(false);
    };

    const addInvoiceRecord = () => {
        setOpen(true);

    }
    return (
        <div className={classes.mainDashboard} >
            <Grid container direction="column" style={{
                position: 'absolute',
                top: '100px',
                left: '30px',
                width: '141px',
                height: '31px',
            }}>



                <Grid item xs={12}>

                    <Typography style={{
                        color: 'white',
                        paddingLeft: '3px'
                    }}>
                        Invoice List
      </Typography>
                    <br></br>
                    <Grid item xs={12}>
                        <Paper sm={12} elevation={3} style={{
                            top: '161px',
                            left: '30px',
                            width: '1200px',
                            height: '60vh',
                            // backgroundColor: '#273D49CC',
                            backgroundColor: theme.palette.primary.light,
                        }}>

                            <Grid container style={{
                                position: 'relative',
                                // backgroundColor: theme.palette.primary.light,
                                top: '10px',
                                left: '10px',
                            }} justify="space-between">
                                <Grid item sm={4}>
                                    <Button style={{
                                        padiding: '2px',
                                        border: '1px solid #97A1A9',
                                        borderRadius: '10px',
                                        color: '#97A1A9',
                                        opacity: '1',
                                    }} variant="outlined">Predict </Button>

                                    <Button style={{

                                        marginLeft: '20px',
                                        border: '1px solid #97A1A9',
                                        borderRadius: '10px',
                                        opacity: '1',
                                        color: '#97A1A9'
                                    }} variant="outlined">View Correspondence </Button>
                                    {/* <SearchIcon/> */}
                                </Grid>

                                <Grid item style={{ justifyItems: 'end' }}>

                                    <Button onClick={addInvoiceRecord} style={{

                                        padiding: '2px',
                                        border: '1px solid #97A1A9',
                                        borderRadius: '10px',
                                        opacity: '1',

                                        textAlign: 'left',
                                        // font: 'normal normal normal 20px/24px Ubuntu',
                                        letterSpacing: '0px',
                                        color: '#FFFFFF',
                                        opacity: '1',
                                    }} variant="outlined">Add </Button>

                                    <Button style={{

                                        marginLeft: '20px',
                                        border: '1px solid #97A1A9',
                                        borderRadius: '10px',
                                        opacity: '1',
                                        textAlign: 'left',
                                        // font: 'normal normal normal 20px/24px Ubuntu',
                                        letterSpacing: '0px',
                                        color: '#97A1A9',
                                        opacity: '1'

                                    }} variant="outlined">Edit</Button>

                                    <Button onClick={handleDeleteClick} style={{
                                        marginLeft: '20px',
                                        border: '1px solid #97A1A9',
                                        borderRadius: '10px',
                                        opacity: '1',
                                        textAlign: 'left',
                                        letterSpacing: '0px',
                                        color: '#97A1A9',
                                        opacity: '1'
                                    }} variant="outlined">Delete </Button>


                                    <Button style={{


                                        marginRight: '20px',
                                        marginLeft: '20px',
                                        border: '1px solid #97A1A9',
                                        borderRadius: '10px',
                                        opacity: '1',
                                        textAlign: 'left',
                                        // font: 'normal normal normal 20px/24px Ubuntu',
                                        letterSpacing: '0px',
                                        color: '#97A1A9',
                                        opacity: '1',
                                        background: '#283A46 0% 0 % no - repeat padding- box',
                                        border: '1px solid #356680',
                                        borderRadius: '10px',
                                        opacity: 1
                                    }} variant="outlined">Search by Invoice Number</Button>

                                </Grid>

                            </Grid>
                            <Grid style={{ paddingTop: '20px' }} >

                                {
                                    open == true && (<AddInvoiceComponent handleCloseProp={handleClose} />)
                                }
                            </Grid>

                        </Paper>
                    </Grid>
                </Grid>
            </Grid>
        </div>
    );


}

const useStyles = makeStyles({
 

}
);

